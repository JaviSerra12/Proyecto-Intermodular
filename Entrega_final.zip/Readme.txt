Proyecto: ActuaYa

Integreantes: 
Cristian Sanchez - Index
Daniel Cantero - Perfil
Iker Jimenez - Anuncios
Javier Serrano - Login/registro/password/password_change

Repositorio: https://github.com/JaviSerra12/Proyecto-Intermodular